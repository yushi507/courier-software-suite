import React from 'react';

export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Courier Admin Dashboard</h1>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow">Stores</div>
        <div className="bg-white p-4 rounded shadow">Riders</div>
        <div className="bg-white p-4 rounded shadow">Orders</div>
        <div className="bg-white p-4 rounded shadow">Map View</div>
      </div>
    </div>
  );
}