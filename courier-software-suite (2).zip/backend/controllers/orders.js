import db from '../db.js';

export const getAllOrders = async (req, res) => {
  const result = await db.query('SELECT * FROM orders');
  res.json(result.rows);
};

export const createOrder = async (req, res) => {
  const { customer_name, pickup, dropoff } = req.body;
  const result = await db.query(
    'INSERT INTO orders (customer_name, pickup, dropoff) VALUES ($1, $2, $3) RETURNING *',
    [customer_name, pickup, dropoff]
  );
  res.status(201).json(result.rows[0]);
};